import { Component } from '@angular/core';
import { IPrinter, APrinter, BPrinter, Printer, PrinterType, PrinterTypeDict } from './printer';
import {classToPlain, plainToClass, serialize, deserialize} from "class-transformer";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'test1';

  constructor() {

    let dict = {};
    dict[PrinterType.A] = APrinter;
    dict[PrinterType.B] = BPrinter;

    let a: IPrinter[] = [];

    a.push(new APrinter("Printer a1", []));
    a.push(new APrinter("Printer a2", []));

    let b: IPrinter[] = [];

    b.push(new BPrinter("Printer b1", a));
    b.push(new BPrinter("Printer b2", []));

    let bb = new BPrinter("Printer bb", a);
    let aa = new APrinter("Printer aa", b);

    console.log(bb.print());

    let s = serialize(aa); //a[0]);

    console.log(s);

    let js = JSON.stringify(s);

    //console.log(js);

    let ds = deserialize<IPrinter>(APrinter, s);

    let realo = deserialize<IPrinter>(PrinterTypeDict.getDict()[ds.type], s); 

    console.log(realo.name);
    console.log(realo.print());
    console.log(realo.calc());
    console.log(realo.desc);

    console.log(serialize((a, b) => {return a + b;}));
    
    //a.forEach((p) => console.log(p.print()));
  }
}
